<?php
$servername = "localhost";
$username = "root"; // Default WAMP username
$password = ""; // Default WAMP password (usually empty)
$dbname = "mydatabase"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $action = $_POST['action'];
    $property_type = $_POST['property_type'];
    $propertycategory = $_POST['propertycategory'];
    $contact = $_POST['contact'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO properties (action, property_type, propertycategory, contact) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $action, $property_type, $propertycategory, $contact);

    // Execute the statement
    if ($stmt->execute()) {
        // Display the submitted data in a table
        echo "<h1>Form Submission Successful!</h1>";
        echo "<table border='1' style='width: 50%; margin: auto;'>";
        echo "<tr><th>Field</th><th>Value</th></tr>";
        echo "<tr><td>You are looking to:</td><td>$action</td></tr>";
        echo "<tr><td>Property Type:</td><td>$property_type</td></tr>";
        echo "<tr><td>Property Category:</td><td>$propertycategory</td></tr>";
        echo "<tr><td>Your Contact:</td><td>$contact</td></tr>";
        echo "</table>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "<h1>Error: Invalid Request</h1>";
}

// Close the connection
$conn->close();
?>
