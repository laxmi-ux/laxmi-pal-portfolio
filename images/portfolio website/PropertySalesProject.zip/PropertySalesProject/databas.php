<?php
$servername = "localhost"; // or your server address
$username = "root"; // your MySQL username
$password = ""; // your MySQL password
$dbname = "create new account"; // your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name']; // Get the 'name' field from the form
    $password = $_POST['password']; // Get the 'password' field

    // Create the SQL query
    $sql = "INSERT INTO users (name, password, email, phone no) VALUES ('$name', '$password','$email', '$phone no')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>