
<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection parameters
$servername = "localhost";
$dbUsername = "root"; // or your database username
$dbPassword = ""; // or your database password
$dbname = "mydatabase"; // your database name

// Create a new database connection
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission


    if (isset($_GET['Username']) && isset($_GET['Password'])) {
        $inputUsername = $_GET['Username'];
        $inputPassword = $_GET['Password'];
    }

    // Check for empty fields
    if (empty($inputUsername) || empty($inputPassword)) {
        echo "Username and password are required.";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("SELECT  Username Password FROM users WHERE Username = '$Username' Password='$Password'");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("s", $inputUsername);
        if (!$stmt->execute()) {
            die("Execute failed: " . $stmt->error);
        }
        
        $stmt->store_result();

        // Check if the user exists
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();

            // Verify the password
            if (password_verify($inputPassword, $hashed_password)) {
                // Start session and redirect to a welcome page
                session_start();
                $_SESSION['username'] = $inputUsername;
                header("Location: connect.php");
                exit();
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "No user found with that username.";
        }

        $stmt->close();
    }

    
$conn->close();
?>
