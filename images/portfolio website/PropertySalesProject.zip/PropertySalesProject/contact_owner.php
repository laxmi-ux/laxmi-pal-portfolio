<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    $owner_phone = htmlspecialchars($_POST['owner_phone']);

    // Here you would normally send an email
    // mail($to, $subject, $message, $headers);

    // For now, just save to the database
    require 'db.php';

    $stmt = $pdo->prepare("INSERT INTO inquiries (name, email, message, owner_phone) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $message, $owner_phone]);

    echo "Your message has been sent to the owner!";
}
?>
