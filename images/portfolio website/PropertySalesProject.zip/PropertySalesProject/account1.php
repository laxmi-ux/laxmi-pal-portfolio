<?php
// Database configuration
$servername = "localhost"; // Your server name (usually localhost)
$username = "root"; // Your database username
$password = ""; // Your database password (leave empty if none)
$dbname = "mydatabase"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Get form data
    $name = $_GET['name'];
    $password = $_GET['password'];
    $email = $_GET['email'];
    $phone = $_GET['phone'];

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (name, password, email, phone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $hashedPassword, $email, $phone);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
